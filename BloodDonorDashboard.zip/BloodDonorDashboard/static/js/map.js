document.addEventListener('DOMContentLoaded', function() {
    // Initialize the map if the container exists
    const mapContainer = document.getElementById('donorMap');
    if (!mapContainer) return;

    // Create a map centered on a default location
    const map = L.map('donorMap').setView([0, 0], 2);

    // Add OpenStreetMap tiles
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    // Custom marker icon
    const donorIcon = L.divIcon({
        html: '<i class="feather icon-heart text-danger"></i>',
        className: 'donor-marker',
        iconSize: [20, 20]
    });

    // Function to load and display donor locations
    function loadDonorLocations() {
        const campaignId = document.querySelector('[name="campaign_id"]')?.value || '1';
        
        fetch(`/api/campaign-stats/${campaignId}`)
            .then(response => response.json())
            .then(data => {
                // Clear existing markers
                map.eachLayer((layer) => {
                    if (layer instanceof L.Marker) {
                        map.removeLayer(layer);
                    }
                });

                // Add markers for each donor location
                if (data.donor_locations) {
                    const bounds = L.latLngBounds();
                    data.donor_locations.forEach(location => {
                        const marker = L.marker([location.lat, location.lng], {
                            icon: donorIcon
                        }).addTo(map);

                        marker.bindPopup(`
                            <strong>${location.name}</strong><br>
                            Blood Type: ${location.blood_type}<br>
                            Date: ${new Date(location.donation_date).toLocaleDateString()}
                        `);

                        bounds.extend([location.lat, location.lng]);
                    });

                    // Fit map to show all markers
                    if (!bounds.isEmpty()) {
                        map.fitBounds(bounds);
                    }
                }
            })
            .catch(error => console.error('Error loading donor locations:', error));
    }

    // Load initial donor locations
    loadDonorLocations();

    // Add refresh button to map
    const refreshButton = L.control({position: 'topright'});
    refreshButton.onAdd = function() {
        const button = L.DomUtil.create('button', 'btn btn-sm btn-primary map-refresh-btn');
        button.innerHTML = '<i class="feather icon-refresh-cw"></i>';
        button.onclick = loadDonorLocations;
        return button;
    };
    refreshButton.addTo(map);

    // Add legend
    const legend = L.control({position: 'bottomright'});
    legend.onAdd = function() {
        const div = L.DomUtil.create('div', 'map-legend');
        div.innerHTML = `
            <h6>Legend</h6>
            <div><i class="feather icon-heart text-danger"></i> Donor Location</div>
        `;
        return div;
    };
    legend.addTo(map);
});
