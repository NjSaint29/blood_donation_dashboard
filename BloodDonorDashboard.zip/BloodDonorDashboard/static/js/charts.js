// Initialize charts when the page loads
document.addEventListener('DOMContentLoaded', function() {
    // Donor Distribution Chart
    const donorDistCtx = document.getElementById('donorDistributionChart').getContext('2d');
    new Chart(donorDistCtx, {
        type: 'bar',
        data: {
            labels: ['18-25', '26-35', '36-45', '46+'],
            datasets: [{
                label: 'Donors by Age Group',
                data: [0, 0, 0, 0], // Will be updated via API
                backgroundColor: [
                    'rgba(255, 99, 132, 0.5)',
                    'rgba(54, 162, 235, 0.5)',
                    'rgba(255, 206, 86, 0.5)',
                    'rgba(75, 192, 192, 0.5)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Blood Type Distribution Chart
    const bloodTypeCtx = document.getElementById('bloodTypeChart').getContext('2d');
    new Chart(bloodTypeCtx, {
        type: 'pie',
        data: {
            labels: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'],
            datasets: [{
                data: [0, 0, 0, 0, 0, 0, 0, 0], // Will be updated via API
                backgroundColor: [
                    '#FF6384',
                    '#36A2EB',
                    '#FFCE56',
                    '#4BC0C0',
                    '#9966FF',
                    '#FF9F40',
                    '#FF6384',
                    '#36A2EB'
                ]
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'right'
                }
            }
        }
    });

    // Load chart data from API
    updateChartData();
});

function updateChartData() {
    // Get the current campaign ID from the page
    const campaignId = document.querySelector('[name="campaign_id"]')?.value || '1';
    
    fetch(`/api/campaign-stats/${campaignId}`)
        .then(response => response.json())
        .then(data => {
            // Update the charts with the received data
            const donorDistChart = Chart.getChart('donorDistributionChart');
            if (donorDistChart) {
                donorDistChart.data.datasets[0].data = Object.values(data.age_groups);
                donorDistChart.update();
            }

            const bloodTypeChart = Chart.getChart('bloodTypeChart');
            if (bloodTypeChart) {
                bloodTypeChart.data.datasets[0].data = Object.values(data.blood_types);
                bloodTypeChart.update();
            }
        })
        .catch(error => console.error('Error loading chart data:', error));
}
