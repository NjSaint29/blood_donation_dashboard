function submitDonorForm(event) {
    event.preventDefault();
    
    const form = event.target;
    const formData = new FormData(form);
    
    // Show loading state
    const submitButton = form.querySelector('button[type="submit"]');
    const originalText = submitButton.innerHTML;
    submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Submitting...';
    submitButton.disabled = true;

    fetch('/submit-donor', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Show success message
            const alert = document.createElement('div');
            alert.className = 'alert alert-success alert-dismissible fade show';
            alert.innerHTML = `
                <strong>Success!</strong> Donor registered successfully. Donor Code: ${data.donor_code}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
            form.insertBefore(alert, form.firstChild);
            
            // Reset form
            form.reset();
        } else {
            throw new Error(data.error || 'Failed to submit form');
        }
    })
    .catch(error => {
        // Show error message
        const alert = document.createElement('div');
        alert.className = 'alert alert-danger alert-dismissible fade show';
        alert.innerHTML = `
            <strong>Error!</strong> ${error.message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        form.insertBefore(alert, form.firstChild);
    })
    .finally(() => {
        // Restore button state
        submitButton.innerHTML = originalText;
        submitButton.disabled = false;
    });
}

// Form validation
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('donorForm');
    
    if (form) {
        // Validate age
        const ageInput = form.querySelector('#age');
        ageInput.addEventListener('input', function() {
            const age = parseInt(this.value);
            if (age < 18) {
                this.setCustomValidity('Minimum age for donation is 18 years');
            } else if (age > 65) {
                this.setCustomValidity('Maximum age for donation is 65 years');
            } else {
                this.setCustomValidity('');
            }
        });

        // Validate weight
        const weightInput = form.querySelector('#weight');
        weightInput.addEventListener('input', function() {
            const weight = parseFloat(this.value);
            if (weight < 50) {
                this.setCustomValidity('Minimum weight for donation is 50 kg');
            } else {
                this.setCustomValidity('');
            }
        });

        // Validate hemoglobin
        const hemoglobinInput = form.querySelector('#hemoglobin');
        hemoglobinInput.addEventListener('input', function() {
            const hemoglobin = parseFloat(this.value);
            if (hemoglobin < 12.5) {
                this.setCustomValidity('Minimum hemoglobin level for donation is 12.5 g/dL');
            } else {
                this.setCustomValidity('');
            }
        });
    }
});
